from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
p=pd.read_csv(R/'paired_changes.csv.gz');g=pd.read_csv(R/'outcome_groups.csv')
fig,ax=plt.subplots(figsize=(9,5));x=np.arange(4);colors=['#2a8c75','#426bb0','#cf694b'];keys=['delta_travel_score','delta_home_score','delta_work_score'];labels=['Travel','Home activity','Work activity']
g=g.set_index(['scenario','outcome']).loc[[('spread30','winner'),('spread30','loser'),('spread60','winner'),('spread60','loser')]]
pos=np.zeros(4);neg=np.zeros(4)
for key,col,lab in zip(keys,colors,labels):
 v=g[key].to_numpy();bottom=np.where(v>=0,pos,neg);ax.bar(x,v,bottom=bottom,color=col,label=lab);pos+=np.maximum(v,0);neg+=np.minimum(v,0)
ax.scatter(x,g.delta_native_score,color='black',marker='D',label='Net score change',zorder=4)
ax.axhline(0,color='#555',lw=.7);ax.set_xticks(x,['30 min: winners','30 min: losers','60 min: winners','60 min: losers']);ax.set_ylabel('Mean change versus own baseline (utils)');ax.set_title('Work-activity score losses outweigh travel and home gains');ax.legend(ncol=2,frameon=False);fig.tight_layout();fig.savefig(R/'score_decomposition.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5))
for scenario,col in [('spread30','#426bb0'),('spread60','#cf694b')]:
 d=p[p.scenario==scenario];bins=np.arange(330,406,5);d=d.copy();d['bin']=pd.cut(d.home_end_s/60,bins,right=False);a=d.groupby('bin',observed=True).agg(n=('person','size'),losers=('outcome',lambda v:100*(v=='loser').mean()));centers=[q.mid for q in a.index];ax.plot(centers,a.losers,'o-',color=col,label=scenario.replace('spread','')+' min window')
ax.set_xticks([330,345,360,375,390],['05:30','05:45','06:00','06:15','06:30']);ax.set(xlabel='Actual home departure (5-minute groups)',ylabel='People with lower daily score (%)',ylim=(-3,103),title='Score losses concentrate among early departures');ax.legend(frameon=False);fig.tight_layout();fig.savefig(R/'departure_loss_groups.png',dpi=180);plt.close(fig)
