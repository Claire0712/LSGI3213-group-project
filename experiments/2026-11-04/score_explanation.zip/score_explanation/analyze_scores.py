"""Reconstruct final-day MATSim 12 scores from events; verify each native selected-plan score."""
from pathlib import Path
import argparse,gzip,xml.etree.ElementTree as E,math,json,hashlib
import pandas as pd,numpy as np
OUT=Path(__file__).resolve().parent

def params(e):return {p.get('name'):p.get('value') for p in e.findall('param')}
def sec(x):
 if x=='undefined':return None
 if ':' not in x:return float(x)
 h,m,s=map(float,x.split(':'));return h*3600+m*60+s

def read(folder,label,seed):
 config=E.parse(folder/'output_config.xml');m=config.find("./module[@name='planCalcScore']");assert params(m)['usingOldScoringBelowZeroUtilityDuration']=='false'
 c=m.find("parameterset[@type='scoringParameters']");p=params(c);a={params(x)['activityType']:params(x) for x in c.findall("parameterset[@type='activityParams']")}
 mode=next(params(x) for x in c.findall("parameterset[@type='modeParams']") if params(x)['mode']=='car')
 for k in ['constant','dailyMonetaryConstant','dailyUtilityConstant','marginalUtilityOfDistance_util_m','monetaryDistanceRate']:assert float(mode[k])==0
 assert float(p['waiting'])==0 and float(p['earlyDeparture'])==0
 def activity(typ,start,end):
  v=a[typ];assert v['scoringThisActivityAtAll']=='true';opening=sec(v['openingTime']);closing=sec(v['closingTime'])
  s=max(start,opening) if opening is not None else start;e=min(end,closing) if closing is not None else end
  if opening is not None and closing is not None and (opening>end or closing<start):s=e=end
  dur=e-s;t=sec(v['typicalDuration']);priority=float(v['priority']);z=t*math.exp(-1/priority) if v['typicalDurationScoreComputation']=='relative' else t*math.exp(-10/(t/3600)/priority)
  beta=float(p['performing'])/3600;u=beta*t*math.log(dur/z) if dur>=z else beta*t*(dur-z)/z
  latest=sec(v['latestStartTime']);late=float(p['lateArrival'])/3600*max(0,s-latest) if latest is not None else 0
  return u,late,dur
 people={};deps={};trips={}
 with gzip.open(folder/'output_events.xml.gz','rb') as f:
  for _,el in E.iterparse(f,events=['end']):
   if el.tag!='event':continue
   x=el.attrib;typ=x['type'];pid=x.get('person');t=float(x['time'])
   assert typ not in ['stuckAndAbort','personMoney']
   if pid is not None:
    r=people.setdefault(pid,{})
    if typ=='actend' and x.get('actType')=='h':assert 'home_end_s' not in r;r['home_end_s']=t
    elif typ=='actstart' and x.get('actType')=='h':r['home_start_s']=t
    elif typ=='actstart' and x.get('actType')=='w':r['work_start_s']=t
    elif typ=='actend' and x.get('actType')=='w':r['work_end_s']=t
    elif typ=='departure':assert x['legMode']=='car';deps[pid]=t
    elif typ=='arrival':trips.setdefault(pid,[]).append(t-deps.pop(pid))
   el.clear()
 native=E.fromstring(gzip.open(folder/'output_plans.xml.gz').read());scores={x.get('id'):float(x.find("plan[@selected='yes']").get('score')) for x in native.findall('person')}
 rows=[]
 for pid,r in people.items():
  assert len(trips[pid])==2
  hs,hl,hd=activity('h',r['home_start_s'],r['home_end_s']+86400);ws,wl,wd=activity('w',r['work_start_s'],r['work_end_s'])
  ts=sum(trips[pid])*float(mode['marginalUtilityOfTraveling_util_hr'])/3600
  rows.append(dict(person=pid,scenario=label,seed=seed,**r,home_duration_s=hd,work_presence_s=r['work_end_s']-r['work_start_s'],work_scored_duration_s=wd,am_travel_s=trips[pid][0],pm_travel_s=trips[pid][1],home_score=hs,work_score=ws,travel_score=ts,late_score=hl+wl,waiting_score=0.,native_score=scores[pid],reconstructed_score=hs+ws+ts+hl+wl))
 df=pd.DataFrame(rows);assert len(df)==2000;err=(df.native_score-df.reconstructed_score).abs().max();assert err<1e-9,err
 assert (df.work_presence_s==28800).all();assert (df.late_score==0).all()
 assert (df.work_end_s < sec(a['w']['closingTime'])).all()
 assert a['h']['openingTime']=='undefined' and a['h']['closingTime']=='undefined'
 return df,dict(scenario=label,seed=seed,people=len(df),max_absolute_score_error=float(err),events_sha256=hashlib.sha256((folder/'output_events.xml.gz').read_bytes()).hexdigest(),config_sha256=hashlib.sha256((folder/'output_config.xml').read_bytes()).hexdigest())

def main(source,extension):
 dfs=[];checks=[]
 for seed in [4711,42,2025]:
  for label,folder in [('baseline',source/'runs'/f'baseline_s{seed}'),('spread30',extension/'runs'/f'cap100_spread30_s{seed}'),('spread60',source/'runs'/f'stagger_s{seed}')]:
   d,c=read(folder,label,seed);dfs.append(d);checks.append(c)
 all=pd.concat(dfs);all.to_csv(OUT/'individual_score_components.csv.gz',index=False)
 base=all[all.scenario=='baseline'];pairs=[]
 cols=['home_score','work_score','travel_score','late_score','waiting_score','native_score','home_duration_s','work_scored_duration_s','am_travel_s','pm_travel_s','home_end_s','home_start_s','work_start_s','work_end_s']
 for label in ['spread30','spread60']:
  d=all[all.scenario==label].merge(base[['person','seed']+cols],on=['person','seed'],suffixes=('','_baseline'),validate='one_to_one')
  for col in cols:d['delta_'+col]=d[col]-d[col+'_baseline']
  d['outcome']=np.where(d.delta_native_score < -1e-9,'loser',np.where(d.delta_native_score>1e-9,'winner','unchanged'))
  d['departure_bin']=d.home_end_s.map(lambda t:f'{int(t//3600):02}:{int(t%3600//900)*15:02}')
  assert np.allclose(d.delta_native_score,d.delta_home_score+d.delta_work_score+d.delta_travel_score+d.delta_late_score,rtol=0,atol=1e-9)
  pairs.append(d)
 pairs=pd.concat(pairs);pairs.to_csv(OUT/'paired_changes.csv.gz',index=False)
 values=['delta_native_score','delta_home_score','delta_work_score','delta_travel_score','delta_home_duration_s','delta_work_scored_duration_s','delta_am_travel_s','delta_home_end_s']
 summary=pairs.groupby(['scenario','outcome']).agg(n=('person','size'),**{v:(v,'mean') for v in values});summary.to_csv(OUT/'outcome_groups.csv')
 pairs.groupby(['scenario','departure_bin']).agg(n=('person','size'),losers_pct=('outcome',lambda x:100*(x=='loser').mean()),**{v:(v,'mean') for v in values}).to_csv(OUT/'departure_groups.csv')
 # Fixed-trajectory accounting counterfactual, not a new behavioral simulation.
 counter=[]
 for seed in [4711,42,2025]:
  b=base[base.seed==seed].set_index('person')
  for label in ['spread30','spread60']:
   d=pairs[(pairs.seed==seed)&(pairs.scenario==label)].copy()
   # All observed work presences are eight hours and inside closing time: removing opening restriction gives identical work score.
   delta=d.delta_home_score+d.delta_travel_score
   counter.append(dict(seed=seed,scenario=label,original_losers_pct=100*(d.outcome=='loser').mean(),no_opening_restriction_fixed_trajectory_losers_pct=100*(delta < -1e-9).mean()))
 pd.DataFrame(counter).to_csv(OUT/'fixed_trajectory_counterfactual.csv',index=False)
 (OUT/'validation.json').write_text(json.dumps(checks,indent=2));print(summary.to_string());print('max reconstruction error',max(c['max_absolute_score_error'] for c in checks))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--source',type=Path,required=True);a.add_argument('--extension',type=Path,required=True);p=a.parse_args();main(p.source,p.extension)
